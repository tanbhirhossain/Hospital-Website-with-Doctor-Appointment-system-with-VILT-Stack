<?php

namespace Modules\APPOINTMENT\Services;

use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Modules\APPOINTMENT\Interfaces\AppointmentRepositoryInterface;
use Modules\APPOINTMENT\Interfaces\AppointmentServiceInterface;
use Modules\APPOINTMENT\Interfaces\TimeSlotServiceInterface;
use Modules\APPOINTMENT\Models\Appointment;
use Modules\APPOINTMENT\Support\AppointmentStatus;

class AppointmentService implements AppointmentServiceInterface
{
    public function __construct(
        private readonly AppointmentRepositoryInterface $appointmentRepository,
        private readonly TimeSlotServiceInterface       $timeSlotService,
    ) {}

    public function createAppointment(array $data)
    {
        if ($this->appointmentRepository->isSlotBooked(
            $data['doctor_id'],
            $data['appointment_date'],
            $data['start_time'],
            $data['end_time'],
        )) {
            throw new \InvalidArgumentException('This time slot is no longer available. Please select another slot.');
        }

        if (!$this->timeSlotService->isWorkingDay($data['doctor_id'], $data['appointment_date'])) {
            throw new \InvalidArgumentException('The selected doctor does not work on this day.');
        }

        if ($this->timeSlotService->isRestDay($data['doctor_id'], $data['appointment_date'])) {
            throw new \InvalidArgumentException('The selected date is a rest day for this doctor.');
        }

        return $this->appointmentRepository->create($data);
    }

    public function updateAppointment(Appointment $appointment, array $data)
    {
        return $this->appointmentRepository->update($appointment, $data);
    }

    public function deleteAppointment(Appointment $appointment): void
    {
        $this->appointmentRepository->delete($appointment);
    }

    public function getAppointment(int $id): ?Appointment
    {
        return $this->appointmentRepository->findById($id);
    }

    public function listAppointments(int $perPage = 15, array $filters = []): LengthAwarePaginator
    {
        return $this->appointmentRepository->paginate($perPage, $filters);
    }

    public function confirmAppointment(Appointment $appointment)
    {
        if ($appointment->status !== AppointmentStatus::PENDING) {
            throw new \InvalidArgumentException('Only pending appointments can be confirmed.');
        }

        return $this->appointmentRepository->update($appointment, [
            'status' => AppointmentStatus::CONFIRMED,
        ]);
    }

    public function cancelAppointment(Appointment $appointment, ?string $reason = null)
    {
        if (!in_array($appointment->status, [AppointmentStatus::PENDING, AppointmentStatus::CONFIRMED])) {
            throw new \InvalidArgumentException('This appointment cannot be cancelled.');
        }

        return $this->appointmentRepository->update($appointment, [
            'status'              => AppointmentStatus::CANCELLED,
            'cancellation_reason' => $reason,
        ]);
    }

    public function completeAppointment(Appointment $appointment)
    {
        if ($appointment->status !== AppointmentStatus::CONFIRMED) {
            throw new \InvalidArgumentException('Only confirmed appointments can be marked as completed.');
        }

        return $this->appointmentRepository->update($appointment, [
            'status' => AppointmentStatus::COMPLETED,
        ]);
    }

    public function markNoShow(Appointment $appointment)
    {
        if ($appointment->status !== AppointmentStatus::CONFIRMED) {
            throw new \InvalidArgumentException('Only confirmed appointments can be marked as no-show.');
        }

        return $this->appointmentRepository->update($appointment, [
            'status' => AppointmentStatus::NO_SHOW,
        ]);
    }

    public function getDashboardStats(): array
    {
        return [
            'total'     => $this->appointmentRepository->countByStatus(null),
            'pending'   => $this->appointmentRepository->countByStatus(AppointmentStatus::PENDING),
            'confirmed' => $this->appointmentRepository->countByStatus(AppointmentStatus::CONFIRMED),
            'completed' => $this->appointmentRepository->countByStatus(AppointmentStatus::COMPLETED),
            'cancelled' => $this->appointmentRepository->countByStatus(AppointmentStatus::CANCELLED),
            'no_show'   => $this->appointmentRepository->countByStatus(AppointmentStatus::NO_SHOW),
        ];
    }
}
