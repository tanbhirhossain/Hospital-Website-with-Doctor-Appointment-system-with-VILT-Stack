<?php

namespace Modules\DOCTOR\Database\Factories;

use Modules\DOCTOR\Models\CenterOfExcellence;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<CenterOfExcellence>
 */
class CenterOfExcellenceFactory extends Factory
{
    protected $model = CenterOfExcellence::class;

    public function definition(): array
    {
        return [
            //
        ];
    }
}