<?php

namespace Modules\HEALTHAI\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response as InertiaResponse;
use Modules\HEALTHAI\Services\Agent\AiAgentService;

/**
 * Thin HTTP controller — delegates all AI logic to AiAgentService.
 *
 * Responsibilities:
 *   - Validate HTTP input
 *   - Call the service
 *   - Return HTTP response
 *
 * Nothing else.
 */
final class AiAgentController extends Controller
{
    public function __construct(private readonly AiAgentService $agentService) {}

    /**
     * Handle an incoming chat message and return an AI-generated Bangla reply.
     */
    public function handleRequest(Request $request): JsonResponse
    {
        $userMessage = trim($request->input('message', ''));

        if (empty($userMessage)) {
            return response()->json([
                'reply' => 'বিনীতভাবে জানাচ্ছি, আপনার প্রশ্নটি আমি বুঝতে পারিনি।',
            ]);
        }

        try {
            $reply = $this->agentService->handle($userMessage);
            return response()->json(['reply' => $reply]);
        } catch (\Throwable $e) {
            report($e); // Channels to Laravel's exception handler (Sentry, Telescope, etc.)
            return response()->json([
                'reply' => 'সিস্টেমে একটি অভ্যন্তরীণ ত্রুটি ঘটেছে। দয়া করে আবার চেষ্টা করুন।',
            ], 500);
        }
    }

    /**
     * Render the Chat Agent UI via Inertia.
     */
    public function index(): InertiaResponse
    {
        return Inertia::render('HEALTHAI::ChatAgent');
    }
}