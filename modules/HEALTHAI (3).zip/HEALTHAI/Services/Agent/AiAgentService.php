<?php

namespace Modules\HEALTHAI\Services\Agent;

use Illuminate\Support\Facades\Log;
use Modules\HEALTHAI\Prompts\AgentPrompts;

/**
 * Orchestrates the three-step AI Agent pipeline:
 *   1. Route  — determine user intent via LLM + PHP fallback
 *   2. Fetch  — retrieve structured context data from the correct source
 *   3. Reply  — synthesize context into a fluent Bangla response via LLM
 */
final class AiAgentService
{
    public function __construct(
        private readonly IntentRouter $router,
        private readonly AgentDataResolverFactory $resolverFactory,
        private readonly OllamaClient $ollama,
    ) {}

    public function handle(string $userMessage): string
    {
        // Step 1 — Route
        $decision = $this->router->resolve($userMessage);

        Log::info('[AiAgentService] Routing resolved', [
            'intent'  => $decision->intent->value,
            'keyword' => $decision->keyword,
        ]);

        // Step 2 — Fetch
        $resolver    = $this->resolverFactory->make($decision->intent);
        $contextData = $resolver->resolve($decision->keyword);

        // Step 3 — Reply
        return $this->generateReply($userMessage, $contextData, $decision->intent->value);
    }

    private function generateReply(string $userMessage, array $contextData, string $intent): string
    {
        $prompt = AgentPrompts::finalReply($userMessage, json_encode($contextData), $intent);
        $reply  = $this->ollama->chat($prompt);

        if ($reply === null) {
            Log::error('[AiAgentService] Final reply generation failed', ['user_message' => $userMessage]);
            return 'উত্তর তৈরি করার সময় একটি সমস্যা হয়েছে। দয়া করে আবার চেষ্টা করুন।';
        }

        return $reply;
    }
}