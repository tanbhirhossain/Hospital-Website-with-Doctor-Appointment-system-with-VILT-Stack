<?php

namespace Modules\HEALTHAI\Services\Agent;

use Modules\HEALTHAI\Enums\AgentIntent;
use Modules\HEALTHAI\Services\Agent\Resolvers\BedResolver;
use Modules\HEALTHAI\Services\Agent\Resolvers\COEResolver;
use Modules\HEALTHAI\Services\Agent\Resolvers\DepartmentResolver;
use Modules\HEALTHAI\Services\Agent\Resolvers\DoctorResolver;
use Modules\HEALTHAI\Services\Agent\Resolvers\ExcelResolver;
use Modules\HEALTHAI\Services\Agent\Resolvers\GeneralResolver;
use Modules\HEALTHAI\Services\Agent\Resolvers\PharmacyResolver;
use RuntimeException;

/**
 * Maps an AgentIntent to its DataResolver.
 *
 * To add a new intent:
 *   1. Add case to AgentIntent enum.
 *   2. Create a class implementing DataResolverInterface.
 *   3. Register it in resolverClass() below.
 *
 * NOTE: We use a match() instead of a const array because PHP does not allow
 * enum ->value expressions as constant array keys at compile time.
 */
final class AgentDataResolverFactory
{
    public function make(AgentIntent $intent): DataResolverInterface
    {
        $resolverClass = $this->resolverClass($intent);
        return app($resolverClass);
    }

    /**
     * @return class-string<DataResolverInterface>
     */
    private function resolverClass(AgentIntent $intent): string
    {
        return match ($intent) {
            AgentIntent::EXCEL               => ExcelResolver::class,
            AgentIntent::DATABASE_DOCTOR     => DoctorResolver::class,
            AgentIntent::DATABASE_DEPARTMENT => DepartmentResolver::class,
            AgentIntent::DATABASE_COE        => COEResolver::class,
            AgentIntent::API_BEDS            => BedResolver::class,
            AgentIntent::API_PHARMACY        => PharmacyResolver::class,
            AgentIntent::GENERAL             => GeneralResolver::class,
        };
    }
}
