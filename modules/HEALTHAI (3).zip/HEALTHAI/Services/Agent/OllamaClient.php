<?php

namespace Modules\HEALTHAI\Services\Agent;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

final class OllamaClient
{
    private string $endpoint;

    public function __construct(
        private readonly string $baseUrl,
        private readonly string $model,
        private readonly int $timeoutSeconds = 60,
    ) {
        $this->endpoint = rtrim($baseUrl, '/') . '/api/chat';
    }

    /**
     * Chat with JSON format enforced (used for routing).
     *
     * @return array<string, mixed>|null  Decoded JSON, or null on failure.
     */
    public function chatJson(string $prompt): ?array
    {
        try {
            $response = Http::timeout($this->timeoutSeconds)->post($this->endpoint, [
                'model'   => $this->model,
                'messages' => [['role' => 'user', 'content' => $prompt]],
                'stream'  => false,
                'format'  => 'json',
            ]);

            $raw = $response->json()['message']['content'] ?? '{}';

            // Strip markdown code fences if LLM wraps the JSON
            $clean = preg_replace('#```(?:json)?\s*(.*?)\s*```#s', '$1', $raw);

            return json_decode(trim($clean), true) ?? null;
        } catch (\Throwable $e) {
            Log::error('[OllamaClient] chatJson failed', ['error' => $e->getMessage()]);
            return null;
        }
    }

    /**
     * Chat for free-form text (used for final reply generation).
     */
    public function chat(string $prompt): ?string
    {
        try {
            $response = Http::timeout($this->timeoutSeconds)->post($this->endpoint, [
                'model'    => $this->model,
                'messages' => [['role' => 'user', 'content' => $prompt]],
                'stream'   => false,
            ]);

            return $response->json()['message']['content'] ?? null;
        } catch (\Throwable $e) {
            Log::error('[OllamaClient] chat failed', ['error' => $e->getMessage()]);
            return null;
        }
    }
}
