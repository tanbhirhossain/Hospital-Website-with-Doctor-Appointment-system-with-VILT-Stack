<?php

namespace Modules\HEALTHAI\Services\Agent\Resolvers;

use Modules\HEALTHAI\Services\Agent\DataResolverInterface;
use Modules\HEALTHAI\Services\ExcelService;
use Modules\HEALTHAI\Services\MISDataService;
use Modules\WEBSITE\Services\COEService;
use Modules\WEBSITE\Services\DepartmentService;
use Modules\WEBSITE\Services\DoctorService;

// ---------------------------------------------------------------------------
// 1. EXCEL — Test price lookup
// ---------------------------------------------------------------------------

final class ExcelResolver implements DataResolverInterface
{
    private const GENERIC_KEYWORDS = ['test', 'list', 'all', 'everything', 'shob'];

    public function __construct(private readonly ExcelService $excelService) {}

    public function resolve(string $keyword): array
    {
        if (empty($keyword) || in_array(mb_strtolower(trim($keyword)), self::GENERIC_KEYWORDS, true)) {
            return [[
                'Notice' => 'আমাদের AMZ হাসপাতালে প্যাথলজি, বায়োকেমিস্ট্রি, ইমেজিং সহ সব ধরণের টেস্টের সুব্যবস্থা রয়েছে। '
                          . 'সুনির্দিষ্ট টেস্টের নাম (যেমন: CBC, Lipid Profile, USG) বললে আমি এখনই মূল্য জানিয়ে দিচ্ছি।',
            ]];
        }

        $results = $this->excelService->searchTestPrice($keyword);

        return $results ?: [[
            'Notice' => 'টেস্টের মূল্য ডাটাবেজে পাওয়া যায়নি। বিস্তারিত জানতে হটলাইনে কল করুন।',
        ]];
    }
}

// ---------------------------------------------------------------------------
// 2. DATABASE_DOCTOR — Doctor schedule lookup
// ---------------------------------------------------------------------------

final class DoctorResolver implements DataResolverInterface
{
    private const STRIP_WORDS = ['"', "'", 'er', 'doctor', 'daktar', 'kara', 'keo', 'ache', 'ki', '?'];

    public function __construct(private readonly DoctorService $doctorService) {}

    public function resolve(string $keyword): array
    {
        $clean      = KeywordHelper::clean($keyword, self::STRIP_WORDS);
        $allDoctors = $this->doctorService->getAllDoctors();
        $doctors    = KeywordHelper::isGeneric($clean)
            ? $allDoctors
            : $allDoctors->filter(fn ($d) => $this->matches($d, $clean));

        if ($doctors->isEmpty()) {
            return [[
                'Notice' => "বর্তমানে '{$keyword}' বিভাগের কোনো ডাক্তারের শিডিউল পাওয়া যায়নি। অনুগ্রহ করে হেল্পলাইনে যোগাযোগ করুন।",
            ]];
        }

        return $doctors->map(fn ($doctor) => [
            'Type'        => 'Doctor',
            'Name'        => $doctor->name,
            'Designation' => $doctor->designation ?? 'Consultant',
            'Department'  => $doctor->department->name ?? 'General',
            'Schedule'    => $this->formatSchedule($doctor->timetables ?? []),
        ])->values()->all();
    }

    private function matches(object $doctor, string $keyword): bool
    {
        $name  = mb_strtolower($doctor->name ?? '');
        $desig = mb_strtolower($doctor->designation ?? '');
        $dept  = $doctor->department ? mb_strtolower($doctor->department->name) : '';

        if (stripos($name, $keyword) !== false)  return true;
        if (stripos($desig, $keyword) !== false) return true;

        if (!empty($dept)) {
            if (stripos($dept, $keyword) !== false || stripos($keyword, $dept) !== false) {
                return true;
            }

            // Token-level match: "Orthopedics & Trauma" → individual words
            $tokens = array_filter(
                explode(' ', str_replace(['&', 'and', 'or', ','], ' ', $keyword)),
                fn ($w) => strlen($w) > 3,
            );
            foreach ($tokens as $token) {
                if (stripos($dept, $token) !== false) return true;
            }
        }

        return false;
    }

    private function formatSchedule(iterable $timetables): string
    {
        $slots = [];
        foreach ($timetables as $slot) {
            $slots[] = "{$slot->day}: {$slot->start_time} - {$slot->end_time}";
        }
        return $slots ? implode(', ', $slots) : 'শিডিউল জানতে কল করুন';
    }
}

// ---------------------------------------------------------------------------
// 3. DATABASE_DEPARTMENT — Department listing
// ---------------------------------------------------------------------------

final class DepartmentResolver implements DataResolverInterface
{
    private const STRIP_WORDS = ['department', 'bivag', 'ডিপার্টমেন্ট', 'বিভাগ', '"', "'", '?'];

    public function __construct(private readonly DepartmentService $departmentService) {}

    public function resolve(string $keyword): array
    {
        $clean       = KeywordHelper::clean($keyword, self::STRIP_WORDS);
        $departments = KeywordHelper::unwrapPaginator($this->departmentService->getAllDepartmentsForAI());
        $isGeneric   = KeywordHelper::isGeneric($clean);

        $matched = array_filter(
            $departments,
            fn ($d) => $isGeneric || stripos($d->name, $clean) !== false,
        );

        // Fallback to full list if specific search yields nothing
        $list = !empty($matched) ? $matched : $departments;

        return array_values(array_map(
            fn ($dept) => ['Type' => 'Department', 'Name' => $dept->name],
            $list,
        ));
    }
}

// ---------------------------------------------------------------------------
// 4. DATABASE_COE — Center of Excellence lookup
// ---------------------------------------------------------------------------

final class COEResolver implements DataResolverInterface
{
    private const STRIP_WORDS = ['center of excellence', 'center', 'excellence', 'coe', 'সেন্টার', 'এক্সেলেন্স', '?'];

    public function __construct(private readonly COEService $coeService) {}

    public function resolve(string $keyword): array
    {
        $clean     = KeywordHelper::clean($keyword, self::STRIP_WORDS);
        $coes      = (array) $this->coeService->getAllCOEs();
        $isGeneric = KeywordHelper::isGeneric($clean);

        $matched = array_filter($coes, fn ($c) => $isGeneric || stripos($c->name, $clean) !== false);
        $list    = !empty($matched) ? $matched : $coes;

        return array_values(array_map(fn ($coe) => [
            'Type'        => 'Center of Excellence',
            'Name'        => $coe->name,
            'Description' => strip_tags($coe->description ?? 'Specialized medical center of AMZ Hospital.'),
        ], $list));
    }
}

// ---------------------------------------------------------------------------
// 5. API_BEDS — Live bed status from MIS ERP
// ---------------------------------------------------------------------------

final class BedResolver implements DataResolverInterface
{
    public function __construct(private readonly MISDataService $misService) {}

    public function resolve(string $keyword): array
    {
        $data = KeywordHelper::unwrapJsonResponse($this->misService->getBeds());

        if (empty($data) || isset($data['error'])) {
            return [[
                'Notice' => 'এই মুহূর্তে বেডের লাইভ স্ট্যাটাস পাওয়া যাচ্ছে না। অনুগ্রহ করে হটলাইনে কল করুন।',
            ]];
        }

        return [['Type' => 'Live Bed Status', 'Data' => $data]];
    }
}

// ---------------------------------------------------------------------------
// 6. API_PHARMACY — Live pharmacy/medicine stock from MIS ERP
// ---------------------------------------------------------------------------

final class PharmacyResolver implements DataResolverInterface
{
    private const STRIP_WORDS = [
        'medicine', 'pharmacy', 'price', 'ase', 'ache', 'ki', 'apnader', 'ekhane',
        'tablet', 'capsule', 'ঔষধ', 'ওষুধ', 'ফার্মেসি', 'ট্যাবলেট', 'আছে', 'কি', 'নাকি',
        '?', '.', '"', "'",
    ];

    public function __construct(private readonly MISDataService $misService) {}

    public function resolve(string $keyword): array
    {
        $clean = KeywordHelper::clean($keyword, self::STRIP_WORDS);
        $data  = KeywordHelper::unwrapJsonResponse($this->misService->searchPharmacy($clean));

        if (empty($data) || isset($data['error'])) {
            return [[
                'Notice' => "দুঃখিত, ফার্মেসির স্টকে '{$clean}' ওষুধটির তথ্য পাওয়া যায়নি।",
            ]];
        }

        return [['Type' => 'Pharmacy Medicine Status', 'Keyword' => $clean, 'Data' => $data]];
    }
}

// ---------------------------------------------------------------------------
// 7. GENERAL — Static hospital info (handled entirely by the LLM prompt)
// ---------------------------------------------------------------------------

final class GeneralResolver implements DataResolverInterface
{
    public function resolve(string $keyword): array
    {
        return []; // Static info is embedded in AgentPrompts::finalReply()
    }
}
